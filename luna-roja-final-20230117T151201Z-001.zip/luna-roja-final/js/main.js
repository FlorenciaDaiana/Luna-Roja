//ANIMACION DEL INICIO//

var animation = lottie.loadAnimation({
    container: document.getElementById('lottie'), // Required
    path: 'animacionCorta.json', // Required
    renderer: 'svg', // Required
    loop: false, // Optional
    autoplay: true, // Optional
    name: "Hero", // Name for future reference. Optional.
})

animation.setSpeed(0.3);


//ANIMACION NAVBAR//

const header = document.querySelector("header");


// ANIMACION INICIO

let sr = ScrollReveal({
    duration: 2800,
    distance: "80px"
});

sr.reveal("#navbar", {origin: "top", delay: 1200 })



//CALCULADORA

// datos arbitrarios
var valorToallita = 65;
var periodosAnuales = 12;
var carbonoToallitas = 0.029;
var carbonoTampones = 0.018;
var hidricoToallitas = 7.5;
var hidricoTampones = 6.9;
var anualCopa = 1;
var valorCopa = 1500;
var carbonoCopita = (0.42 / 10) / 12;
var hidricoCopita = 900;
var residuosToallitas = 0.0183;
var residuosTampones = 0.0106;
var residuosCopita = 0.015;

function increment(inputID) {
    document.getElementById(inputID).stepUp();
}

function decrement(inputID) {
    document.getElementById(inputID).stepDown();
}

function mostrarResultados() {
    var DiasPeriodo = document.getElementById('DiasPeriodo').value
    var Toallitas = document.getElementById('Toallitas').value
    var Tampones = document.getElementById('Tampones').value

    var toallasAnual = DiasPeriodo * Toallitas * periodosAnuales;
    var tamponesAnual = DiasPeriodo * Tampones * periodosAnuales;
    var copaAnual = anualCopa;

    var dineroToallitas = toallasAnual * valorToallita;
    var dineroTampones = tamponesAnual * valorToallita;
    var dineroCopita = valorCopa;

    var toallitaHidrica = toallasAnual * hidricoToallitas;
    var tamponesHidrica = tamponesAnual * hidricoTampones;
    var copitaHidrica = anualCopa * hidricoCopita;

    var toallitaCarbono = toallasAnual * carbonoToallitas;
    var tamponesCarbono = toallasAnual * carbonoTampones;
    var copitaCarbono = anualCopa * carbonoCopita;

    //Huella Carbono Calculos
    document.getElementById("huCarResultado").innerHTML = toallitaCarbono + tamponesCarbono;
    document.getElementById("huCarCoresultado").innerHTML = copitaCarbono;

    //Huella Hidrica Calculos
    document.getElementById("huhiResultado").innerHTML = toallitaHidrica + tamponesHidrica;
    document.getElementById("huhiCoResultado").innerHTML = copitaHidrica;

    //Dinero Invertido Calculos
    document.getElementById("pesosResultado").innerHTML = dineroToallitas + dineroTampones;
    document.getElementById("precioCoresultado").innerHTML = dineroCopita;

    //Cantidad de Productos Calculos
    document.getElementById("unidadToallresultado").innerHTML = toallasAnual + tamponesAnual;
    document.getElementById("unidadCoresultado").innerHTML = copaAnual;
    }